﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMovement : MonoBehaviour
{

    private float moveSpeed = 4;
    private float rotateSpeed = 3;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //Generate random number between 0 and 2, to choose direction of movement
        int pos = Random.Range(0, 99);

        //Move agent forward
        transform.Translate(new Vector3(0f, moveSpeed * Time.deltaTime, 0f));

        //Choose direction to move in based on random number generated.
        if (pos <= 10)
        {
            transform.Rotate(Vector3.forward * -rotateSpeed);
        }
        if (pos >= 11 && pos <= 21)
        {
            transform.Rotate(Vector3.forward * rotateSpeed);
        }
        else { }
    }
}
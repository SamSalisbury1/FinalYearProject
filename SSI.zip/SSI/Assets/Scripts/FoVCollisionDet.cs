﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoVCollisionDet : MonoBehaviour
{
    List<GameObject> nearbyAgents = new List<GameObject>();
    List<GameObject> nearbyAgentsRotation = new List<GameObject>();

    // Use this for initialization
    void Start()
    {

    }

    /// <summary>
    /// Called when a new agent is detected, used to add that agent to a list.
    /// </summary>
    /// <param name="other"></param>
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "GreenAgent" && other.gameObject != transform.root.gameObject)
        {
            nearbyAgents.Add(other.transform.root.gameObject);
            Debug.Log("Gotcha");
        }
    }


    /// <summary>
    /// Called when agents are nearby, used to collect a list of nearby agents.
    /// </summary>
    /// <param name="other"></param>
    void OnTriggerStay2D(Collider2D other)
    {
        //While there are agents within the field of view make a list of all rotations.
        if (other.tag == "GreenAgent" && other.gameObject != this.transform.root.gameObject)
        {
            nearbyAgentsRotation.Add(other.gameObject);
        }
    }


    /// <summary>
    /// Called when an agent is out of field of view, used to remove that agent fron nearby agent list.
    /// </summary>
    /// <param name="other"></param>
    private void OnTriggerExit2D(Collider2D other)
    {
        //Remove agent that left FoV
        for (int i = 0; i < nearbyAgents.Count; i++)
        {
            if (nearbyAgents[i] == other.transform.root.gameObject)
            {
                nearbyAgents.RemoveAt(i);
                break;
            }
        }
    }


    //Call every frame
    private void Update()
    {
        nearbyAgentsRotation.Clear();
    }
}

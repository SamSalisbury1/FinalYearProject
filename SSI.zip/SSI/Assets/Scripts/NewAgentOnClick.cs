﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewAgentOnClick : MonoBehaviour
{

    Vector3 textPos;
    private Object cloneText;
    // Use this for initialization
    void Start()
    {      
        textPos.x = 0f;
        textPos.y = 0f;
        textPos.z = 0f;
        cloneText = Instantiate(Resources.Load("rClickSpawnCvas"), textPos, Quaternion.Euler(0, 0, 0));
    }


    private GameObject Agent;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            //Get location of mouse upon clicking on screen and instantiate new agent on that location
            Vector3 pz = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            pz.z = 0;
            Instantiate(Resources.Load("Agent"),pz,Quaternion.identity);
        }

        if (Input.GetButtonDown("Fire2"))
        {
            //Get location of mouse upon clicking on screen and instantiate new agent on that location
            Vector3 pz = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            pz.z = 0;
            Instantiate(Resources.Load("SimpleAutoAgent"), pz, Quaternion.Euler(0,0,90));

            Destroy(cloneText);
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeftBorderScript : MonoBehaviour
{

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Agent" || other.tag == "GreenAgent")
        {
            other.gameObject.transform.position = new Vector3(12.25f, other.gameObject.transform.position.y, 0f);
        }
    }
}

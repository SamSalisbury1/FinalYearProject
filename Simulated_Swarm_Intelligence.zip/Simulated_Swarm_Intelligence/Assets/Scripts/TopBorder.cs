﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopBorder : MonoBehaviour {


    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Agent")
        {
            other.gameObject.transform.position = new Vector3(other.gameObject.transform.position.x, -6f, 0f);
        }
    }
}

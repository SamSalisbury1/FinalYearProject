﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class NewBehaviourScript : MonoBehaviour {

    void Start()
    {
        InvokeRepeating("SetRandomPos", 0, 1);
    }

    void SetRandomPos()
    {
        Vector3 temp = new Vector3(Random.range(-10.6f, 10.6f), Random.range(-10.6f, 10.6f), Random.range(-10.6f, 10.6f));
        transform.position = temp;
    }
}

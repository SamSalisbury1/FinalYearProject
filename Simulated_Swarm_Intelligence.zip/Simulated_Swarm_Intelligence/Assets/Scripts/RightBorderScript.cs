﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RightBorderScript : MonoBehaviour
{

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Agent")
        {
            other.gameObject.transform.position = new Vector3(-13f, other.gameObject.transform.position.y, 0f);
        }
    }
}
